# Skill impact
