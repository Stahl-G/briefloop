"""Product and research CLI. Host-agent product requests invoke no model."""
import argparse
import json
import shutil
from pathlib import Path
from . import __version__


def main(argv=None):
    parser=argparse.ArgumentParser(prog='wikiskill',description='Compile experience into validated agent skills')
    parser.add_argument('--version',action='version',version=f'WikiSkill {__version__}')
    sub=parser.add_subparsers(dest='command',required=True)
    init=sub.add_parser('init',help='Initialize an empty experiment; no model calls')
    init.add_argument('workspace',type=Path)
    init.add_argument('--domain',required=True,choices=['officeqa','officeqa-retrieval','livemath','spreadsheet','sealqa','alfworld'])
    init.add_argument('--model',required=True)
    init.add_argument('--optimizer-model')
    init.add_argument('--effort',default='medium')
    init.add_argument('--optimizer-effort',default='medium')
    init.add_argument('--iterations',type=int,default=4)
    init.add_argument('--workers',type=int,default=4)
    init.add_argument('--timeout',type=int,default=1800)
    for name in ['data','csv','corpus','split-dir']:init.add_argument('--'+name,type=Path)
    for name in ['evolve','status']:
        cmd=sub.add_parser(name,help='Run/resume train-val evolution' if name=='evolve' else 'Read experiment state')
        cmd.add_argument('workspace',type=Path)
        if name=='status':cmd.add_argument('--human',action='store_true',help='Readable product progress and recovery actions')
    demo=sub.add_parser('demo',help='Deterministic offline demonstration; no model calls')
    demo.add_argument('workspace',type=Path)
    sub.add_parser('doctor',help='Check runtime availability without model calls')
    report=sub.add_parser('results',help='Verify and summarize the bundled research snapshot')
    report.add_argument('--snapshot',type=Path)
    study=sub.add_parser('spreadsheet-study',help='Opt-in isolated macOS single-round Spreadsheet study')
    actions=study.add_subparsers(dest='study_action',required=True)
    prep=actions.add_parser('prepare',help='Freeze a bounded train/val study; no model calls')
    prep.add_argument('workspace',type=Path)
    for name in ['data','split-dir','libreoffice-app']:prep.add_argument('--'+name,type=Path,required=True)
    prep.add_argument('--model',default='gpt-5.6-luna')
    prep.add_argument('--effort',default='high')
    prep.add_argument('--train-limit',type=int,default=8)
    prep.add_argument('--val-limit',type=int,default=4)
    prep.add_argument('--workers',type=int,default=2)
    prep.add_argument('--timeout',type=int,default=1800)
    for action in ['run','status','verify']:
        cmd=actions.add_parser(action,help='Run/resume real model calls' if action=='run' else 'Read/verify frozen study')
        cmd.add_argument('workspace',type=Path)
    preflight=actions.add_parser('preflight',help='Check dependencies and native read boundary; no model inference')
    preflight.add_argument('--libreoffice-app',type=Path,required=True)
    preflight.add_argument('--model',default='gpt-5.6-luna')
    preflight.add_argument('--effort',default='high')
    from . import product_cli
    product_cli.register(sub)
    args=parser.parse_args(argv)
    try:
        if args.command in product_cli.COMMANDS:
            result=product_cli.handle(args)
            if args.command=='report' and args.format=='markdown':
                from .product_views import report_markdown
                print(report_markdown(result))
            else:print(json.dumps(result,ensure_ascii=False,indent=2))
            return 2 if args.command=='preflight' and not result['ready'] else 0
        if args.command=='status' and (args.workspace/'config.json').exists():
            from .product import status
            result=status(args.workspace)
            if args.human:
                from .product_views import status_text
                print(status_text(result))
            else:print(json.dumps(result,ensure_ascii=False,indent=2))
            return 0
        if args.command=='spreadsheet-study':
            if args.study_action=='preflight':
                from .isolated.runtime import preflight
                result=preflight(libreoffice_app=args.libreoffice_app,model=args.model,effort=args.effort)
            else:
                from .spreadsheet import study
                if args.study_action=='prepare':
                    values={k:v for k,v in vars(args).items() if k not in {'command','study_action','workspace'}}
                    result=study.prepare(args.workspace,**values)
                else:result=getattr(study,args.study_action)(args.workspace)
            print(json.dumps(result,ensure_ascii=False,indent=2));return 0
        if args.command=='doctor':
            from .product_views import identity
            print(json.dumps({**identity(),'codex':shutil.which('codex'),'note':'CLI discovery only; auth and model access are not tested.'},indent=2));return 0
        if args.command=='results':
            from .results import verify
            print(json.dumps(verify(args.snapshot),indent=2));return 0
        from . import engine
        if args.command=='init':
            config={k:str(v.resolve()) if isinstance(v,Path) else v for k,v in vars(args).items() if k not in {'command','workspace'}}
            config['optimizer_model']=args.optimizer_model or args.model
            if args.domain.startswith('officeqa') and (not args.csv or not args.corpus):parser.error('OfficeQA requires --csv and --corpus')
            if not args.domain.startswith('officeqa') and not args.data:parser.error('This domain requires --data')
            result=engine.initialize(args.workspace,config)
        elif args.command=='demo':
            engine.initialize(args.workspace,{'domain':'demo','model':'offline-demo','optimizer_model':'offline-demo',
                'effort':'none','optimizer_effort':'none','iterations':3,'workers':2,'timeout':10})
            result=engine.evolve(args.workspace)
        elif args.command=='status':result=engine.state(args.workspace.resolve())
        else:result=engine.evolve(args.workspace)
        print(json.dumps(result,ensure_ascii=False,indent=2));return 0
    except (ValueError,RuntimeError,OSError,KeyError) as exc:
        parser.exit(2,f'WikiSkill: {exc}\n')


if __name__=='__main__':raise SystemExit(main())
